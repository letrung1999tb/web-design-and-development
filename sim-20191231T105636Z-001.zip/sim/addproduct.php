<?php  include('DB.php'); ?>
<?php 
	session_start();
	$db = mysqli_connect('localhost', 'root', '', 'tbl_product');

	// initialize variables
	$id = "";
	$name = "";
	$image = "";
	$price = "";
	

	if (isset($_POST['save'])) {
		$id = $_POST['id'];
		$name = $_POST['name'];
		$image = $_POST['image'];
		$price = $_POST['price'];

		mysqli_query($db, "INSERT INTO tbl_product (id,name, image,price) VALUES ('$id', '$name','$image','$price')"); 
		$_SESSION['message'] = "Done saved"; 
		header('location: addproduct.php');
	}

	?>
<?php 
//delete 
if (isset($_POST['del'])) {
	$id = $_GET['id'];
	$sql = "DELETE FROM `tbl_product` WHERE `tbl_product`.`id` = $id";
	$_SESSION['message'] = "deleted!"; 
	header('location: addproduct.php');
}

?>




<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<link rel="stylesheet" type="text/css" href="stylesheettoindexx.css">
<link rel="stylesheet" href="bootstrap.min.css" >
		<link rel="stylesheet" href="stylesheet.css">
<body>
	<body class="container">
		
<div class="topnav" style="background-color: #E7D5D5"><a style="margin-left: 980px " href="login.php">Login</a>
 <input type="text" placeholder="Search.."></div>

<div class="topnav" >
  <a class="navbar-brand" href=""><img src="https://img.icons8.com/material/24/000000/clothes.png"></a>
  <a  href="navigation1.html">Home</a>
  <a href="index.php">Category</a>
  <a href="about.html">About</a>
  <a href="contact.php">Contact</a>
 

</div>
 
	<h2>CREATE PRODUCTS BY ADMIN</h2>
	<form method="post"  >
		<div class="input-group">
			<label>Id</label>
			<input type="text" name="id" value="">
		</div>
		<div class="input-group">
			<label>Name</label>
			<input type="text" name="name" value="">
		</div>
		<div class="input-group">
			<label>Image</label>
			<input type="text" name="image" value="">
		</div>
		<div class="input-group">
			<label>Price</label>
			<input type="text" name="price" value="">
		</div>
		<div class="input-group">
			<button class="btn" type="submit" name="save" >Save</button>
		</div>
		
	</form>
	<form method="post" action="addproduct.php"><div class="input-group">
			<button class="btn" type="submit" name="del" >Delete</button></form>









</body>
</html>