<?php 
session_start();
$connect = mysqli_connect("localhost", "root", "", "tbl_product");
//add to cart
if(isset($_POST["add_to_cart"]))//su dung phuong thuc post de gui thong tin toi gio hang, nó kiểm tra xem biến có tên "add_to_cart"được truyền cho tập lệnh php hay không, nếu đúng, thì nó sẽ đánh giá một biến khác được gọi shopping_cart.
{
	if(isset($_SESSION["shopping_cart"]))//xac dinh 1 phien duoc khai bao
	{
		$item_array_id = array_column($_SESSION["shopping_cart"], "item_id");// neu bien truyen vao dung thi 
		//no se thuc thi dong lenh if
		if(!in_array($_GET["id"], $item_array_id))//ược sử dụng để kiểm tra nếu giá trị tồn tại trong mảng bằng hàm in_array(array, value to check). Vì có dấu chấm than biểu thị toán tử KHÔNG logic, nên hành vi thực sẽ kiểm tra xem các giá trị không tồn tại trong mảng.Nếu điều này xảy ra, thì tập lệnh sẽ kích hoạt một cửa sổ cảnh báo.
		{
			$count = count($_SESSION["shopping_cart"]);
			$item_array = array(
				'item_id'			=>	$_GET["id"],
				'item_name'			=>	$_POST["hidden_name"],
				'item_price'		=>	$_POST["hidden_price"],
				'item_quantity'		=>	$_POST["quantity"]
			);
			$_SESSION["shopping_cart"][$count] = $item_array;
		}
		else
		{
			echo '<script>alert("Item Already Added")</script>';
		}
	}
	else
	{
		$item_array = array(
			'item_id'			=>	$_GET["id"],
			'item_name'			=>	$_POST["hidden_name"],
			'item_price'		=>	$_POST["hidden_price"],
			'item_quantity'		=>	$_POST["quantity"]
		);
		$_SESSION["shopping_cart"][0] = $item_array;
	}
}
//remove
if(isset($_GET["action"]))//xac dinh 1 hanh dong 
{
	if($_GET["action"] == "delete")
	{
		foreach($_SESSION["shopping_cart"] as $keys => $values)// trong bản cập nhật, bạn sẽ thêm một mảng con mới mỗi lần, thay vì gán cho một chỉ mục cố định.
		{
			if($values["item_id"] == $_GET["id"])//neu ket qua cua id =id thi no se thuc thi 
			{
				unset($_SESSION["shopping_cart"][$keys]);//tra ve khoa ma con tro toi thuc thi hanh dong
				echo '<script>window.location="index.php"</script>';//thanh cong se tra ve index.php
			}
		}
	}
}

?>
<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" href="bootstrap.min.css" >
		<link rel="stylesheet" href="stylesheet.css">
		<style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
  background-color: whitesmoke;
}
</style>
	</head>

	<body class="container">
		
<div class="topnav" style="background-color: #E7D5D5"><a style="margin-left: 980px " href="login.php">Login</a>
 <input type="text" placeholder="Search.."></div>

<div class="topnav" >
  <a class="navbar-brand" href=""><img src="https://img.icons8.com/material/24/000000/clothes.png"></a>
  <a  href="navigation1.html">Home</a>
  <a href="index.php">Category</a>
  <a href="about.html">About</a>
  <a href="contact.php">Contact</a>
 

</div>
 
		<br />
		<div class="container">
			<br />
			<br />
			<br />
			<h1 align="center"><a href="" > Shopping Here</a></h1><br />
			<br /><br />
			<?php
				$query = "SELECT * FROM tbl_product ORDER BY id ASC";
				$result = mysqli_query($connect, $query);
				if(mysqli_num_rows($result) > 0)
				{
					while($row = mysqli_fetch_array($result))
					{
				?>
			<div class="col-md-3" >
				<form method="post" action="index.php?action=add&id=<?php echo $row["id"]; ?>">
					<div class="border table-bordered bg-success " >
						<img class="img-responsive" style="height: 300px;" src="images/<?php echo $row["image"]; ?>"  /><br />

						<h4 class="text-justify"><?php echo $row["name"]; ?></h4>

						<h4 class="text-danger">$ <?php echo $row["price"]; ?></h4>

						<input type="text" name="quantity" value="1" class="form-control" />

						<input type="hidden" name="hidden_name" value="<?php echo $row["name"]; ?>" />

						<input type="hidden" name="hidden_price" value="<?php echo $row["price"]; ?>" />

						<input type="submit" name="add_to_cart" style="margin-top:5px;" class="btn btn-success" value="Add to Cart" />

					</div>
				</form>
			</div>
			<?php
					}
				}
			?>
			<div class="container"></div>
			<br />
			<h2>Order Details</h2>
			<div class="table-responsive">
				<table class="table table-bordered">
					<tr>
						<th width="40%">Item Name</th>
						<th width="10%">Quantity</th>
						<th width="20%">Price</th>
						<th width="15%">Total</th>
						<th width="5%">Action</th>
					</tr></div>
					<?php
					if(!empty($_SESSION["shopping_cart"]))//trong php dùng để kiểm tra một biến nào đó có giá trị rỗng hoặc chưa được khởi tạo hay không. !o dau la toan tu k phai la rong. 
					{
						$total = 0;
						foreach($_SESSION["shopping_cart"] as $keys => $values)//trong bản cập nhật, bạn sẽ thêm một mảng con mới mỗi lần, thay vì gán cho một chỉ mục cố định. // cho foreach la moi phien lam viec
						{
					?>
					<tr>
						<td><?php echo $values["item_name"]; ?></td><!-- khai bao ket qua la item name -->
						<td><?php echo $values["item_quantity"]; ?></td>
						<td>$ <?php echo $values["item_price"]; ?></td>
						<td>$ <?php echo number_format($values["item_quantity"] * $values["item_price"], 2);?></td><!-- number format se dinh dang so co dau phay, so 2 la hang chuc duoc lam tron -->
						<td><a href="index.php?action=delete&id=<?php echo $values["item_id"]; ?>"><span class="text-danger">Remove</span></a></td>
					</tr>
					<?php
							$total = $total + ($values["item_quantity"] * $values["item_price"]);
						}
					?>
					<tr>
						<td colspan="3" align="right">Total</td>
						<td align="right">$ <?php echo number_format($total, 2); ?></td>
						<td></td>
					</tr>
					<?php
					}
					?>
						
				</table>
				
				<button 
						style="margin-top:5px; margin-left:1000px;height: 100px;width: 100px"
					class="btn btn-success"
				 onclick="window.location.href='oder.php'">Oder Now</button>

				
			</div>
		</div>
	</div>
	<br />
	</body>
</html>


