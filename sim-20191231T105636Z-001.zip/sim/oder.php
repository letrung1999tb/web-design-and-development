<!DOCTYPE html>
<html>
<head>

	<title> </title>
	<link rel="stylesheet" href="bootstrap.min.css" >
		<link rel="stylesheet" href="stylesheet.css">
</head>
<body class="container-fluid"
background="images/oder.jpg"	>
<div class="topnav ">
  <a  href="navigation1.html">Home</a>
  <a href="http://localhost/sim/index.php">Category</a>
  <a href="about.html">About</a>
  <a href="contact.php">Contact</a>
  <input type="text" placeholder="Search..">
</div>
<h1 style="color: #000000">Order successful, please take a screenshot "Oder details" and bring it to the store for the best support</h1>
<br>
<br>
<br>
<br>




<h1 style="color: #000000" > If you wants oder online,please take a screenshot "Oder detail" and send it to email <a href="trunglvgbh17254@fpt.edu.vn">trunglvgbh17254@fpt.edu.vn</a> or call <a href="tel:0973925011">+84973925011</a></h1>
</body>
</html>