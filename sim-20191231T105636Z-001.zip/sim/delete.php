<?php  include('DB.php'); ?>
<?php  include('addproduct.php'); ?>
<?php 
	session_start();
	$db = mysqli_connect('localhost', 'root', '', 'tbl_product');

	

if(isset($_POST['delete']))
{
    $data = getPosts();
    $delete_Query = "DELETE FROM tbl_product WHERE 'id' = $id";
    try{
        $delete_Result = mysqli_query($connect, $delete_Query);
        
        if($delete_Result)
        {
            if(mysqli_affected_rows($connect) > 0)
            {
                echo 'Data Deleted';
            }else{
                echo 'Data Not Deleted';
            }
        }
    } catch (Exception $ex) {
        echo 'Error Delete '.$ex->getMessage();
    }
}
?>
<!DOCTYPE html>
<html>
<head>
	
	<link rel="stylesheet" type="text/css" href="stylesheettoindexx.css">
</head>
<body>

<form method="post" >
<div class="input-group">
			 <input type="number" name="id" placeholder="Id" value="<?php echo $id;?>"><br><br>
			<input type="submit" name="delete" value="Delete">


		</div>

         
		</form>
</body>
</html>