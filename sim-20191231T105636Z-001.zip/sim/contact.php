<!DOCTYPE html>
<html>
<head>
		<link rel="stylesheet" href="bootstrap.min.css" >
		<link rel="stylesheet" href="stylesheet.css">
		<style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
  background-color: whitesmoke;
}
</style>
	</head>
<body class="container" background="images/bg-01.jpg">
<div class="topnav" style="background-color: #E7D5D5"><a style="margin-left: 1000px " href="login.php">Login</a>
 <input type="text" placeholder="Search.."></div>

	<div class="topnav">	
  <a class="active" href="navigation1.html">Home</a>
  <a href="http://localhost/sim/index.php">Category</a>
  <a href="about.html">About</a>
  <a href="contact.php">Contact</a>
  
</div>	

<center ><table border="0">
    <tr>
      <td ><p style="color: red;

    font-weight: bold;">15, DONG QUAN, CAU GIAY,HN</p>
        <p>CONTACT: +84964534211<br>
          shopclothesdongquan@gmail.com                      </p>

      </td>
      <td ><p style="color: red;

    font-weight: bold;" >7,TRAN HUNG DAO,TP.THAI BINH</p>
        <p> +84972615433<br>
        shopchothesthaibinh@gmail.com </p>


      </td>
      <td><p style="color: red;

    font-weight: bold;">7, THAI THANH, TP.HCM</p>

        <p>+84901827366<br>shopclotheshcm@gmail.com</p>
      </td>



    </tr>
  </table></center>



</body>
</html>