<?php  
 require('db_connect_login.php');

if (isset($_POST['user_id']) and isset($_POST['user_pass'])){
	
// Assigning POST values to variables.
$username = $_POST['user_id'];
$password = $_POST['user_pass'];

// CHECK FOR THE RECORD FROM TABLE
$query = "SELECT * FROM `user_login` WHERE username='$username' and Password='$password'";
 
$result = mysqli_query($connection, $query) or die(mysqli_error($connection));
$count = mysqli_num_rows($result);

if ($count == 1){

//echo "login successfull will move to admin page with function are add and delete
echo '<script>window.location="addproduct.php"</script>';

}



else{
echo "<script type='text/javascript'>alert('Invalid Login Credentials')</script>";

//echo "Invalid Login Credentials";
}
}
?>